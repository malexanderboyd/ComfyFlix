# ComfyFlix

## The key to great sleep!


ComfyFlix is a chrome extension that will skip the countdown timer between episodes on Netflix. 

Also, ComfyFlix features a sleep mode available by right clicking the icon. This allows you to set a counter for the number of episodes to skip before redirecting to Netflix so
your episodes don't run all night!